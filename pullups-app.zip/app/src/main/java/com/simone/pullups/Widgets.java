package com.simone.pullups;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Iterator;
import java.util.Locale;

/**
 * Draws the four home-screen widgets. The app page sends a snapshot of the stats for today and the
 * next 8 days (see widgetData() in index.html); the widgets pick the snapshot for the current date,
 * so they roll over at midnight even while the app stays closed.
 */
public final class Widgets {
    static final int TOTAL = 0, TODAY = 1, WEEK = 2, STATS = 3;
    static final Class<?>[] PROVIDERS = {TotalWidget.class, TodayWidget.class, WeekWidget.class, StatsWidget.class};
    static final int[][] DEFAULT_DP = {{72, 72}, {160, 72}, {320, 160}, {320, 160}};
    static final String PREFS = "widgets", KEY = "data";
    static final String[] DAYS = {"M", "T", "W", "T", "F", "S", "S"};

    private Widgets() {
    }

    // ---- data ----

    static void save(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
    }

    static JSONObject load(Context c) {
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
            return s == null ? null : new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    /** The snapshot for today, or the latest one before today if the app hasn't been opened for a while. */
    static JSONObject snapshot(JSONObject data) {
        if (data == null) return null;
        JSONObject snaps = data.optJSONObject("snaps");
        if (snaps == null) return null;
        String today = LocalDate.now().toString();
        if (snaps.has(today)) return snaps.optJSONObject(today);
        String best = null;
        for (Iterator<String> it = snaps.keys(); it.hasNext(); ) {
            String k = it.next();
            if (k.compareTo(today) <= 0 && (best == null || k.compareTo(best) > 0)) best = k;
        }
        return best == null ? null : snaps.optJSONObject(best);
    }

    // ---- updating ----

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int kind = 0; kind < PROVIDERS.length; kind++) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, PROVIDERS[kind]));
            for (int id : ids) update(c, m, id, kind);
        }
        scheduleMidnight(c);
    }

    static void update(Context c, AppWidgetManager m, int id, int kind) {
        try {
            Bundle o = m.getAppWidgetOptions(id);
            int wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (wdp <= 0 || hdp <= 0) {
                wdp = DEFAULT_DP[kind][0];
                hdp = DEFAULT_DP[kind][1];
            }
            float density = Math.min(c.getResources().getDisplayMetrics().density, 3.5f);
            boolean night = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
            JSONObject data = load(c);
            Bitmap bmp = render(c, kind, wdp, hdp, density, night, data);

            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
            v.setImageViewBitmap(R.id.img, bmp);
            v.setContentDescription(R.id.img, describe(kind, data));
            v.setOnClickPendingIntent(R.id.wroot, open(c, null));
            boolean scan = kind == WEEK || kind == STATS;
            v.setViewVisibility(R.id.scan, scan ? View.VISIBLE : View.GONE);
            if (scan) v.setOnClickPendingIntent(R.id.scan, open(c, "scan"));
            m.updateAppWidget(id, v);
        } catch (Exception ignored) {
        }
    }

    static PendingIntent open(Context c, String action) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (action != null) i.putExtra("action", action);
        return PendingIntent.getActivity(c, action == null ? 10 : 11, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Refreshes the widgets just after midnight, so "today" moves on without opening the app. */
    static void scheduleMidnight(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long at = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 60_000;
            PendingIntent pi = PendingIntent.getBroadcast(c, 20, new Intent(c, WidgetTick.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            am.set(AlarmManager.RTC, at, pi);
        } catch (Exception ignored) {
        }
    }

    static String describe(int kind, JSONObject data) {
        JSONObject s = snapshot(data);
        if (data == null || s == null) return "Pull-ups. Open the app to start.";
        long total = data.optLong("total");
        switch (kind) {
            case TOTAL:
                return total + " pull-ups in total";
            case TODAY:
                return s.optInt("n") + " pull-ups today, goal " + data.optInt("goal", 30);
            case WEEK:
                return s.optInt("tw") + " pull-ups this week, " + s.optInt("cur") + " day streak";
            default:
                return total + " pull-ups in total, " + s.optInt("cur") + " day streak";
        }
    }

    // ---- drawing ----

    static Typeface semi, bold, heavy;

    static void fonts(Context c) {
        if (heavy != null) return;
        try {
            semi = Typeface.createFromAsset(c.getAssets(), "wfonts/Inter-SemiBold.otf");
            bold = Typeface.createFromAsset(c.getAssets(), "wfonts/Inter-Bold.otf");
            heavy = Typeface.createFromAsset(c.getAssets(), "wfonts/Inter-ExtraBold.otf");
        } catch (Exception e) {
            semi = bold = heavy = Typeface.DEFAULT_BOLD;
        }
    }

    /** Colours, matching the app (Twilight palette). */
    static final class Pal {
        int card, ink, mu, ln, at, ac, ac2, r2, rs, vc, sk;

        Pal(boolean night) {
            if (night) {
                card = 0xFF1C1C1E; ink = 0xFFF5F5F7; mu = 0xFF98989F; ln = 0xFF38383A; at = 0xFFFF9F0A;
                ac = 0xFFFF9F0A; ac2 = 0xFFFF8A00; r2 = 0xFFFFD35A; rs = 0xFF7D7AFF; vc = 0xFF64D2FF; sk = 0xFFFF375F;
            } else {
                card = 0xFFFFFFFF; ink = 0xFF1C1C1E; mu = 0xFF6C6C70; ln = 0xFFE9E9EE; at = 0xFFB35A00;
                ac = 0xFFFF9500; ac2 = 0xFFFF7A00; r2 = 0xFFFFC247; rs = 0xFF5E5CE6; vc = 0xFF30B0D8; sk = 0xFFFF375F;
            }
        }
    }

    static int alpha(int color, float a) {
        return Color.argb(Math.round(a * 255), Color.red(color), Color.green(color), Color.blue(color));
    }

    static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        return p;
    }

    static Paint stroke(int color, float w) {
        Paint p = fill(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        return p;
    }

    static Paint text(Typeface tf, float size, int color) {
        Paint p = fill(color);
        p.setTypeface(tf);
        p.setTextSize(size);
        return p;
    }

    /** Shrinks a text paint until the string fits in maxWidth. */
    static Paint fit(Paint p, String s, float maxWidth) {
        while (p.getTextSize() > 6 && p.measureText(s) > maxWidth) p.setTextSize(p.getTextSize() * 0.92f);
        return p;
    }

    static void centerText(Canvas cv, String s, float cx, float cy, Paint p) {
        Paint.FontMetrics fm = p.getFontMetrics();
        p.setTextAlign(Paint.Align.CENTER);
        cv.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2, p);
    }

    static String num(long n) {
        return String.format(Locale.getDefault(), "%,d", n);
    }

    static Bitmap render(Context c, int kind, int wdp, int hdp, float d, boolean night, JSONObject data) {
        fonts(c);
        Bitmap b = Bitmap.createBitmap(Math.max(1, Math.round(wdp * d)), Math.max(1, Math.round(hdp * d)), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        cv.scale(d, d);
        Pal p = new Pal(night);
        JSONObject s = snapshot(data);
        switch (kind) {
            case TOTAL:
                drawTotal(cv, wdp, hdp, data);
                break;
            case TODAY:
                drawToday(cv, wdp, hdp, p, data, s);
                break;
            case WEEK:
                drawWeek(cv, wdp, hdp, p, data, s);
                break;
            default:
                drawStats(cv, wdp, hdp, p, data, s);
        }
        return b;
    }

    static void card(Canvas cv, float w, float h, Pal p) {
        cv.drawRoundRect(new RectF(0, 0, w, h), 24, 24, fill(p.card));
    }

    /** Dark counter box with light digit wheels, like the app icon. */
    static void wheels(Canvas cv, RectF box, String digits, boolean dim) {
        float h = box.height(), pad = h * 0.12f, gap = Math.max(2, box.width() * 0.025f);
        cv.drawRoundRect(box, h * 0.22f, h * 0.22f, fill(0xFF121214));
        int n = digits.length();
        float ww = (box.width() - 2 * pad - (n - 1) * gap) / n;
        Paint tp = text(heavy, (h - 2 * pad) * 0.66f, dim ? 0x55111111 : 0xFF111111);
        tp.setTextSize(Math.min(tp.getTextSize(), ww * 1.15f));
        for (int i = 0; i < n; i++) {
            RectF r = new RectF(box.left + pad + i * (ww + gap), box.top + pad, box.left + pad + i * (ww + gap) + ww, box.bottom - pad);
            cv.drawRoundRect(r, ww * 0.18f, ww * 0.18f, fill(0xFFFAFAF7));
            centerText(cv, digits.substring(i, i + 1), r.centerX(), r.centerY(), tp);
        }
    }

    static void scanButton(Canvas cv, float w, Pal p) {
        float cx = w - 32, cy = 30;
        cv.drawCircle(cx, cy, 16, fill(alpha(p.ac, 0.18f)));
        Paint st = stroke(p.at, 1.7f);
        Path body = new Path();
        body.moveTo(cx - 7.5f, cy - 3.5f);
        body.lineTo(cx - 4.2f, cy - 3.5f);
        body.lineTo(cx - 2.6f, cy - 6f);
        body.lineTo(cx + 2.6f, cy - 6f);
        body.lineTo(cx + 4.2f, cy - 3.5f);
        body.lineTo(cx + 7.5f, cy - 3.5f);
        body.lineTo(cx + 7.5f, cy + 6f);
        body.lineTo(cx - 7.5f, cy + 6f);
        body.close();
        cv.drawPath(body, st);
        cv.drawCircle(cx, cy + 1.2f, 2.8f, st);
    }

    // 1x1: looks like the app icon, shows the all-time total.
    static void drawTotal(Canvas cv, float w, float h, JSONObject data) {
        float s = Math.min(w, h), ox = (w - s) / 2, oy = (h - s) / 2;
        cv.save();
        cv.translate(ox, oy);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setShader(new LinearGradient(0, 0, 0, s, 0xFFFFAB2E, 0xFFFF7A00, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(0, 0, s, s), s * 0.24f, s * 0.24f, bg);

        long total = data == null ? 0 : data.optLong("total");
        String t = Long.toString(total);
        float bw = s * 0.84f, bh = s * 0.34f, x0 = (s - bw) / 2, y0 = s * 0.33f;
        if (t.length() <= 5) {
            if (t.length() < 3) t = String.format(Locale.US, "%03d", total);
            wheels(cv, new RectF(x0, y0, x0 + bw, y0 + bh), t, data == null);
        } else {
            RectF r = new RectF(x0, y0, x0 + bw, y0 + bh);
            cv.drawRoundRect(r, bh * 0.22f, bh * 0.22f, fill(0xFF121214));
            String k = String.format(Locale.US, "%.1fk", total / 1000f);
            centerText(cv, k, r.centerX(), r.centerY(), fit(text(heavy, bh * 0.6f, 0xFFFAFAF7), k, bw * 0.85f));
        }
        // pull-up bar
        float t1 = bh * 0.1f, by = y0 - bh * 0.42f;
        cv.drawRoundRect(new RectF(x0 + bw * 0.06f, by, x0 + bw * 0.94f, by + t1), t1 / 2, t1 / 2, fill(0xFF241300));
        cv.drawRoundRect(new RectF(x0 + bw * 0.14f, by, x0 + bw * 0.14f + t1, y0 + 1), t1 / 3, t1 / 3, fill(0xFF241300));
        cv.drawRoundRect(new RectF(x0 + bw * 0.86f - t1, by, x0 + bw * 0.86f, y0 + 1), t1 / 3, t1 / 3, fill(0xFF241300));
        Paint lp = text(bold, s * 0.12f, 0xFF241300);
        centerText(cv, "pull-ups", s / 2, y0 + bh + (s - y0 - bh) * 0.46f, fit(lp, "pull-ups", s * 0.8f));
        cv.restore();
    }

    static String stateWord(String st) {
        switch (st) {
            case "r":
            case "fr":
                return "Rest day";
            case "v":
            case "fv":
                return "On vacation";
            case "k":
                return "Skipped";
            default:
                return null;
        }
    }

    static int stateColor(String st, Pal p) {
        if (st.equals("r") || st.equals("fr")) return p.rs;
        if (st.equals("v") || st.equals("fv")) return p.vc;
        if (st.equals("k")) return p.sk;
        return p.ink;
    }

    // 2x1: counter wheels plus today's pull-ups and goal bar.
    static void drawToday(Canvas cv, float w, float h, Pal p, JSONObject data, JSONObject s) {
        card(cv, w, h, p);
        float pad = Math.min(12, h * 0.16f);
        int dg = data == null ? 4 : Math.max(3, Math.min(6, data.optInt("dg", 4)));
        long counter = data == null || data.isNull("counter") ? 0 : data.optLong("counter");
        String digits = String.format(Locale.US, "%0" + dg + "d", counter % (long) Math.pow(10, dg));
        float bh = h - 2 * pad, digitW = bh * 0.62f;
        float bw = Math.min(dg * digitW + bh * 0.24f, (w - 2 * pad) * (w < 150 ? 0.46f : 0.52f));
        wheels(cv, new RectF(pad, pad, pad + bw, pad + bh), digits, data == null || data.isNull("counter"));

        float x = pad + bw + 10, rw = w - x - pad;
        if (rw < 34) return;
        int goal = data == null ? 30 : Math.max(1, data.optInt("goal", 30));
        int n = s == null ? 0 : s.optInt("n");
        String st = s == null ? "p" : s.optString("s", "p");
        Paint lab = text(semi, 11.5f, p.at);
        cv.drawText("Today", x, pad + 12, lab);
        String word = n > 0 ? null : stateWord(st);
        float mid = pad + bh * 0.58f;
        if (word != null) {
            Paint wp = fit(text(heavy, Math.min(20, bh * 0.36f), stateColor(st, p)), word, rw);
            cv.drawText(word, x, mid + wp.getTextSize() * 0.35f, wp);
        } else {
            Paint np = text(heavy, Math.min(30, bh * 0.5f), p.ink);
            String ns = Integer.toString(n), gs = " / " + goal;
            Paint gp = text(bold, np.getTextSize() * 0.45f, p.mu);
            float total = np.measureText(ns) + gp.measureText(gs);
            if (total > rw) {
                float k = rw / total;
                np.setTextSize(np.getTextSize() * k);
                gp.setTextSize(gp.getTextSize() * k);
            }
            float base = mid + np.getTextSize() * 0.36f;
            cv.drawText(ns, x, base, np);
            cv.drawText(gs, x + np.measureText(ns), base, gp);
        }
        RectF bar = new RectF(x, h - pad - 6, w - pad, h - pad);
        cv.drawRoundRect(bar, 3, 3, fill(p.ln));
        float f = Math.min(1f, n / (float) goal);
        if (f > 0) {
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(bar.left, 0, bar.right, 0, p.ac, 0xFFFF5E1A, Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(bar.left, bar.top, bar.left + Math.max(6, bar.width() * f), bar.bottom), 3, 3, g);
        }
    }

    static void moon(Canvas cv, float cx, float cy, float r, int color) {
        Path a = new Path(), b = new Path();
        a.addCircle(cx, cy, r, Path.Direction.CW);
        b.addCircle(cx + r * 0.55f, cy - r * 0.45f, r * 0.85f, Path.Direction.CW);
        a.op(b, Path.Op.DIFFERENCE);
        cv.drawPath(a, fill(color));
    }

    static void sun(Canvas cv, float cx, float cy, float r, int color) {
        cv.drawCircle(cx, cy, r * 0.42f, fill(color));
        Paint st = stroke(color, Math.max(1.4f, r * 0.17f));
        for (int i = 0; i < 8; i++) {
            double a = Math.PI / 4 * i;
            cv.drawLine(cx + (float) Math.cos(a) * r * 0.7f, cy + (float) Math.sin(a) * r * 0.7f,
                    cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, st);
        }
    }

    static void cross(Canvas cv, float cx, float cy, float r, int color) {
        Paint st = stroke(color, Math.max(1.6f, r * 0.24f));
        cv.drawLine(cx - r * 0.6f, cy - r * 0.6f, cx + r * 0.6f, cy + r * 0.6f, st);
        cv.drawLine(cx + r * 0.6f, cy - r * 0.6f, cx - r * 0.6f, cy + r * 0.6f, st);
    }

    // 4x2: the week strip from the Today screen.
    static void drawWeek(Canvas cv, float w, float h, Pal p, JSONObject data, JSONObject s) {
        card(cv, w, h, p);
        scanButton(cv, w, p);
        float pad = 16;
        cv.drawText("This week", pad, 36, text(bold, 16, p.ink));
        if (s == null) {
            cv.drawText("Open the app to start tracking", pad, h / 2 + 10, fit(text(semi, 13, p.mu), "Open the app to start tracking", w - 2 * pad));
            return;
        }
        String head = num(s.optInt("tw")) + " · " + s.optInt("cur") + " d streak";
        Paint hp = text(semi, 12, p.mu);
        hp.setTextAlign(Paint.Align.RIGHT);
        float headRight = w - 56;
        fit(hp, head, headRight - pad - 90);
        cv.drawText(head, headRight, 35, hp);

        boolean footer = h >= 140;
        float bottom = h - pad;
        float letterY = footer ? bottom - 20 : bottom - 2;
        float numY = letterY - 14;
        float top = 50, barBottom = numY - 14;
        if (barBottom - top < 16) barBottom = top + 16;
        int goal = data == null ? 30 : Math.max(1, data.optInt("goal", 30));
        JSONArray wk = s.optJSONArray("wk");
        float gap = 6, cw = (w - 2 * pad - 6 * gap) / 7f, rad = Math.min(cw / 2, 11);
        Paint numP = text(bold, 11.5f, p.ink), letP = text(semi, 10.5f, p.mu);
        numP.setTextAlign(Paint.Align.CENTER);
        letP.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < 7; i++) {
            JSONArray day = wk == null ? null : wk.optJSONArray(i);
            int n = day == null ? 0 : day.optInt(0);
            String st = day == null ? "f" : day.optString(1, "f");
            boolean today = day != null && day.optInt(2) == 1;
            float l = pad + i * (cw + gap);
            RectF cap = new RectF(l, top, l + cw, barBottom);
            float cx = cap.centerX(), cy = cap.centerY(), ir = Math.min(cw * 0.32f, 9);
            String label;
            int labelColor = p.ink;
            if (n > 0 || st.equals("w")) {
                cv.drawRoundRect(cap, rad, rad, fill(p.ln));
                float fh = Math.max(n > 0 ? 6 : 0, Math.min(1f, n / (float) goal) * cap.height());
                if (fh > 0) {
                    Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
                    g.setShader(new LinearGradient(0, cap.bottom - fh, 0, cap.bottom, new int[]{p.r2, p.ac, p.ac2}, new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
                    cv.drawRoundRect(new RectF(cap.left, cap.bottom - fh, cap.right, cap.bottom), rad, rad, g);
                }
                label = Integer.toString(n);
            } else if (st.equals("r") || st.equals("fr")) {
                float a = st.equals("fr") ? 0.5f : 1f;
                cv.drawRoundRect(cap, rad, rad, fill(alpha(p.rs, 0.17f * a)));
                moon(cv, cx, cy, ir, alpha(p.rs, a));
                label = st.equals("fr") ? "Plan" : "Rest";
                labelColor = p.rs;
            } else if (st.equals("v") || st.equals("fv")) {
                float a = st.equals("fv") ? 0.5f : 1f;
                cv.drawRoundRect(cap, rad, rad, fill(alpha(p.vc, 0.2f * a)));
                sun(cv, cx, cy, ir, alpha(p.vc, a));
                label = "Away";
                labelColor = p.vc;
            } else if (st.equals("k")) {
                Paint ds = stroke(p.sk, 1.5f);
                ds.setPathEffect(new DashPathEffect(new float[]{4, 3}, 0));
                cv.drawRoundRect(new RectF(cap.left + 0.75f, cap.top + 0.75f, cap.right - 0.75f, cap.bottom - 0.75f), rad, rad, ds);
                cross(cv, cx, cy, ir, p.sk);
                label = "Skip";
                labelColor = p.sk;
            } else {
                cv.drawRoundRect(cap, rad, rad, fill(st.equals("n") ? alpha(p.ln, 0.4f) : p.ln));
                label = st.equals("n") ? "" : "·";
            }
            if (today) {
                cv.drawRoundRect(new RectF(cap.left - 1.5f, cap.top - 1.5f, cap.right + 1.5f, cap.bottom + 1.5f), rad + 1.5f, rad + 1.5f, stroke(p.ac, 2));
            }
            numP.setColor(labelColor);
            numP.setTextSize(label.length() > 3 ? 10f : 11.5f);
            cv.drawText(label, cx, numY, numP);
            letP.setColor(today ? p.at : p.mu);
            cv.drawText(DAYS[i], cx, letterY, letP);
        }

        if (!footer) return;
        int used = s.optInt("used"), allow = s.optInt("allow"), plan = s.optInt("plan"), skip = s.optInt("skip");
        float dx = pad + 5, dy = bottom - 4;
        int dots = Math.max(allow, used + plan);
        for (int i = 0; i < dots; i++) {
            if (i < used) cv.drawCircle(dx, dy, 4.5f, fill(p.rs));
            else {
                Paint o = stroke(i < used + plan ? p.rs : alpha(p.rs, 0.5f), 1.4f);
                if (i < used + plan) o.setPathEffect(new DashPathEffect(new float[]{2, 2}, 0));
                cv.drawCircle(dx, dy, 4f, o);
            }
            dx += 13;
        }
        for (int i = 0; i < skip; i++) {
            cv.drawCircle(dx, dy, 4.5f, fill(p.sk));
            dx += 13;
        }
        String ft = allow > 0 || used > 0 || skip > 0
                ? used + " of " + allow + " rest days used" + (skip > 0 ? " · " + skip + " skipped" : "")
                : "No rest days needed this week";
        cv.drawText(ft, dx + (dots + skip > 0 ? 3 : -5), dy + 4, fit(text(semi, 11, p.mu), ft, w - dx - pad));
    }

    // 4x2: the key numbers.
    static void drawStats(Canvas cv, float w, float h, Pal p, JSONObject data, JSONObject s) {
        card(cv, w, h, p);
        scanButton(cv, w, p);
        float pad = 16;
        cv.drawText("Pull-ups", pad, 35, text(bold, 16, p.ink));
        if (s == null || data == null) {
            cv.drawText("Open the app to start tracking", pad, h / 2 + 10, fit(text(semi, 13, p.mu), "Open the app to start tracking", w - 2 * pad));
            return;
        }
        int goal = Math.max(1, data.optInt("goal", 30)), n = s.optInt("n"), tw = s.optInt("tw"), lw = s.optInt("lw");
        String st = s.optString("s", "p");
        String todayVal = n > 0 ? Integer.toString(n) : st.equals("r") ? "Rest" : st.equals("v") ? "Away" : "0";
        int todayColor = n > 0 ? p.ink : st.equals("r") ? p.rs : st.equals("v") ? p.vc : p.ink;
        String change = lw > 0 ? (tw >= lw ? "↑ " : "↓ ") + Math.round(Math.abs(tw - lw) * 100f / lw) + "% vs last" : "last week " + lw;
        String[][] cells = {
                {"Total", num(data.optLong("total")), "all time"},
                {"Today", todayVal, "goal " + goal},
                {"Streak", s.optInt("cur") + " d", "rest pauses it"},
                {"This week", num(tw), change},
                {"Adherence", s.optInt("cons") + "%", "last 30 days"},
                {"Best day", num(s.optInt("best")), "all time"},
        };
        float top = 46, gw = (w - 2 * pad) / 3f, gh = (h - pad + 2 - top) / 2f;
        boolean sub = gh >= 54;
        float valSize = Math.max(12, Math.min(21, sub ? gh - 34 : gh - 18));
        for (int i = 0; i < 6; i++) {
            float x = pad + (i % 3) * gw, y = top + (i / 3) * gh;
            cv.drawText(cells[i][0], x, y + 10, fit(text(semi, 10.5f, p.at), cells[i][0], gw - 8));
            int vc = i == 1 ? todayColor : p.ink;
            float vb = y + 12 + valSize * 0.92f;
            cv.drawText(cells[i][1], x, vb, fit(text(heavy, valSize, vc), cells[i][1], gw - 8));
            if (sub) {
                int sc = i == 3 && lw > 0 ? (tw >= lw ? 0xFF34C759 : p.sk) : p.mu;
                cv.drawText(cells[i][2], x, vb + 14, fit(text(semi, 10, sc), cells[i][2], gw - 8));
            }
        }
    }

}
