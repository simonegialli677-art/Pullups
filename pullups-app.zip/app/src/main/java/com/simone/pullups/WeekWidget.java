package com.simone.pullups;

public class WeekWidget extends WidgetBase {
    @Override
    int kind() {
        return Widgets.WEEK;
    }
}
