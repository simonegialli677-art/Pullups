package com.simone.pullups;

public class StatsWidget extends WidgetBase {
    @Override
    int kind() {
        return Widgets.STATS;
    }
}
