package com.simone.pullups;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires just after midnight (and after the time or time zone changes) to move the widgets to the new day. */
public class WidgetTick extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        Widgets.updateAll(c);
    }
}
