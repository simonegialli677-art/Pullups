package com.simone.pullups;

public class TotalWidget extends WidgetBase {
    @Override
    int kind() {
        return Widgets.TOTAL;
    }
}
