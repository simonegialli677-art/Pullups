package com.simone.pullups;

public class TodayWidget extends WidgetBase {
    @Override
    int kind() {
        return Widgets.TODAY;
    }
}
