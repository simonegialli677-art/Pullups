# Pull-ups: Android app

GitHub builds the APK on its own servers, so all of this works from your phone in Chrome.
If a button below is missing on your phone, open Chrome's ⋮ menu and turn on **Desktop site**.

## What you need
- `pullups-app.zip`: the app project. Don't unzip it.
- `build-workflow.txt`: the build instructions for GitHub.
- `SIGNING-KEY-keep-private.txt`: your signing key. Never upload it.

## One-time setup (about 15 minutes)

**1. Create the repository**
- Make a free account at github.com.
- Tap **+**, then **New repository**.
- Name it `pullups` and choose **Public**. The in-app updates need this, and no private data is in these files.
- Tap **Create repository**.

**2. Upload the project**
- On the new repository page, tap **uploading an existing file**.
- Pick `pullups-app.zip` and tap **Commit changes**.

**3. Add your signing key**
- Go to **Settings → Secrets and variables → Actions → New repository secret**.
- Add `KEYSTORE_PASSWORD` and `KEYSTORE_B64`, copying the values from `SIGNING-KEY-keep-private.txt`.

**4. Add the build instructions (this starts the first build)**
- Go back to **Code** and tap **Add file → Create new file**.
- Type the name exactly: `.github/workflows/build.yml`. The slashes create the folders.
- Open `build-workflow.txt`, copy everything, paste it into the big box and tap **Commit changes**.
- Open the **Actions** tab and wait about 5 minutes for the green tick.

**5. Install on your Samsung**
- Open `github.com/YOUR-NAME/pullups/releases` and tap **Pullups.apk**, then open the download.
- Samsung blocks app installs from outside the stores while **Auto Blocker** is on. If the install is blocked, go to **Settings → Security and privacy → Auto Blocker**, turn it off, and install. You can turn it back on afterwards.
- Allow Chrome (or My Files) to install apps when asked. If Play Protect warns about an unknown developer, tap **More details → Install anyway**. That's you.

**6. Move your data over**
- In your old version, go to **Settings → Export backup (JSON)**.
- In the new app, go to **Settings → Import backup (JSON)**.
- Enter your Gemini or Grok key again in Settings.

**7. Add the widgets**
- Long-press an empty spot on the home screen, tap **Widgets**, then **Pull-ups**.
- There are four: **Total** (1×1, looks like the app icon), **Today** (2×1), **This week** (4×2) and **Stats** (4×2).
- The camera button on the big widgets opens the scanner straight away.

## Updating (about 1 minute, from your phone)

1. In the repository, tap **Add file → Upload files**.
2. Pick the file I sent you (`index.html` or a new `pullups-app.zip`) and tap **Commit changes**.
3. GitHub builds the new version in about 5 minutes. It always uses the newest file you uploaded, so you don't need to rename or delete anything.
4. The app shows **Update available** (or go to **Settings → Check**). Tap **Update**, then **Install**. Your data stays.

## Good to know
- **Widget updates:** the widgets refresh whenever you save something in the app, and they move to the new day just after midnight on their own.
- **Uninstalling erases the app's data.** Export a backup from Settings now and then.
- **The build failed:** open the failed run on the **Actions** tab. The red step tells you what's missing.
- **"App not installed" when updating:** the secrets no longer match your key file. Check that both still hold the values from that file.
